# MyBTEUP Quiz

A Render + GitHub-ready full-stack quiz web app. Students can attempt quizzes as guests, or log in to save generated quizzes. It supports MCQ, True/False, Fill in the Blank, instant explanations, Hindi/English/Hinglish, text PDFs, notes, public links and topic-only AI generation.

## Before running

1. Create a Supabase project. In **Authentication > Providers**, enable Email and Phone. Configure an SMS provider only if you want SMS verification.
2. Open Supabase **SQL Editor**, paste and run `supabase/schema.sql`.
3. Create a Gemini API key in Google AI Studio.
4. Copy `.env.example` to `.env`, then set every value. **Never expose `SUPABASE_SERVICE_ROLE_KEY` or `GEMINI_API_KEY` in frontend code.**
5. Run `npm install`, then `npm run dev`. Open the Vite URL shown in terminal.

## GitHub and Render deployment

1. Create a new GitHub repository and upload this project (including `render.yaml`).
2. In Render: **New > Blueprint**, select the repository.
3. Enter all environment variables listed in `.env.example`. Do not commit `.env`.
4. Deploy. Render executes `npm install && npm run build`, then starts the Express server, which serves the built React app.
5. In Supabase Authentication URL configuration, add your Render URL to **Site URL** and Redirect URLs.

## Admin

Set `ADMIN_EMAIL` to your email in Render. After that email has signed up once, run the one-line admin promotion query at the bottom of `supabase/schema.sql`. For a production admin panel, enforce role checks in each admin API route; never rely only on a frontend button.

## Important notes

- Google Search grounding and Gemini access depend on current API quotas and region availability. Add per-user quotas before public launch.
- This starter limits uploads and blocks obvious local URL targets. For a high-traffic deployment, move extraction to a worker/queue and use malware scanning.
- The `attempts` table is ready, while the UI dashboard and full admin content-management pages are intentionally the next implementation milestone.
